To use this software:
Unzip the folder, make sure all .py files are unzipped to the same location.
Once unzipped, run "Pyramid stacking.py". Follow the instructions given in that code. It accepts vk4/6 files and csv files that have specifically been exported from the Keyence MultiFileAnalyzer software.
You may need to install certain packages.